// Абстрактный класс
abstract class Employee {
    String name;
    double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Абстрактный метод
    public abstract double calculateSalary();
}

// Разработчик
class Developer extends Employee {
    double bonus = 10000; // фиксированный бонус

    public Developer(String name, double salary) {
        super(name, salary);
    }

    @Override
    public double calculateSalary() {
        return salary + bonus;
    }
}

// Менеджер
class Manager extends Employee {
    double bonus = 20000;

    public Manager(String name, double salary) {
        super(name, salary);
    }

    @Override
    public double calculateSalary() {
        return salary + bonus;
    }
}

// Дизайнер
class Designer extends Employee {
    double bonus = 5000;

    public Designer(String name, double salary) {
        super(name, salary);
    }

    @Override
    public double calculateSalary() {
        return salary + bonus;
    }
}

// Главный класс
public class Main {
    public static void main(String[] args) {
        Developer dev = new Developer("Иван", 100000);
        Manager mgr = new Manager("Ольга", 120000);
        Designer des = new Designer("Анна", 80000);

        System.out.println(dev.name + " получает " + dev.calculateSalary());
        System.out.println(mgr.name + " получает " + mgr.calculateSalary());
        System.out.println(des.name + " получает " + des.calculateSalary());
    }
}