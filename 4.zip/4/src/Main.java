// ==================== ИНТЕРФЕЙС ====================
interface Transferable {
    void transfer(Account to, double amount);
}

// ==================== БАЗОВЫЙ КЛАСС АККАУНТА ====================
class Account implements Transferable {
    public String number;
    public double balance;

    // Конструктор
    public Account(String number, double balance) {
        this.number = number;
        this.balance = balance;
    }

    // Конструктор для создания копии
    public Account(Account other) {
        this.number = other.number;
        this.balance = other.balance;
    }

    public void deposit(double amount) {
        balance = balance + amount;
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance = balance - amount;
        } else {
            System.out.println("Недостаточно денег на счету " + number);
        }
    }

    @Override
    public void transfer(Account to, double amount) {
        if (balance >= amount) {
            balance = balance - amount;
            to.balance = to.balance + amount;
            System.out.println("Переведено " + amount + " со счета " + number + " на счет " + to.number);
        } else {
            System.out.println("Ошибка перевода: не хватает денег!");
        }
    }

    @Override
    public boolean equals(Object obj) {
        Account other = (Account) obj;
        return this.number.equals(other.number);
    }

    @Override
    public String toString() {
        return "Счет " + number + ", Баланс: " + balance;
    }
}

// ==================== СБЕРЕГАТЕЛЬНЫЙ СЧЕТ ====================
class SavingsAccount extends Account {
    public double percent;

    public SavingsAccount(String number, double balance, double percent) {
        super(number, balance);
        this.percent = percent;
    }

    // Конструктор копии
    public SavingsAccount(SavingsAccount other) {
        super(other);
        this.percent = other.percent;
    }

    public void addInterest() {
        balance = balance + (balance * percent / 100);
    }

    @Override
    public String toString() {
        return "Сберегательный счет " + number + ", Баланс: " + balance + ", Процент: " + percent + "%";
    }
}

// ==================== КРЕДИТНЫЙ СЧЕТ ====================
class CreditAccount extends Account {
    public double limit;

    public CreditAccount(String number, double balance, double limit) {
        super(number, balance);
        this.limit = limit;
    }

    // Конструктор копии
    public CreditAccount(CreditAccount other) {
        super(other);
        this.limit = other.limit;
    }

    @Override
    public void withdraw(double amount) {
        if ((balance + limit) >= amount) {
            balance = balance - amount;
        } else {
            System.out.println("Превышен лимит по кредиту на счету " + number);
        }
    }

    @Override
    public String toString() {
        return "Кредитный счет " + number + ", Баланс: " + balance + ", Лимит: " + limit;
    }
}

// ==================== ГЛАВНЫЙ КЛАСС (MAIN) ====================
public class Main {
    public static void main(String[] args) {
        // Создаем счета
        SavingsAccount acc1 = new SavingsAccount("111", 1000, 10);
        CreditAccount acc2 = new CreditAccount("222", 0, 500);

        System.out.println("--- Исходные счета ---");
        System.out.println(acc1);
        System.out.println(acc2);

        System.out.println("\n--- Начисление процентов ---");
        acc1.addInterest();
        System.out.println(acc1);

        System.out.println("\n--- Перевод со счета 111 на счет 222 ---");
        acc1.transfer(acc2, 300);
        System.out.println(acc1);
        System.out.println(acc2);

        System.out.println("\n--- Снятие денег с кредитного счета ---");
        acc2.withdraw(100);
        System.out.println(acc2);

        System.out.println("\n--- Создание копии аккаунта ---");
        SavingsAccount acc1Copy = new SavingsAccount(acc1);
        System.out.println("Оригинал: " + acc1);
        System.out.println("Копия:    " + acc1Copy);
        System.out.println("\n--- Сравнение через equals() ---");
        if (acc1.equals(acc1Copy)) {
            System.out.println("Счета совпали по номеру!");
        } else {
            System.out.println("Счета разные!");
        }
    }
}