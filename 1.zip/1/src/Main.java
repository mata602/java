class Student {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 16 && age <= 100) {
            this.age = age;
        } else {
            System.out.println("Возраст должен быть от 16 до 100");
        }
    }
}


class Animal {
    public void makeSound() {
        System.out.println("Животное издает звук");
    }
}


class Dog extends Animal {
    public void makeSound() {
        System.out.println("Гав-гав");
    }
}


class Cat extends Animal {
    public void makeSound() {
        System.out.println("Мяу");
    }
}


public class Main {
    public static void main(String[] args) {

        Student s = new Student();

        s.setName("Иван");
        s.setAge(17);

        System.out.println(s.getName());
        System.out.println(s.getAge());

        Dog dog = new Dog();
        Cat cat = new Cat();

        dog.makeSound();
        cat.makeSound();
    }
}