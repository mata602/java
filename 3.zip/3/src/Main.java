interface Printable {
    void print();
}

interface Savable {
    void save();
}

interface Exportable {
    void export();
}


class Document implements Printable, Savable {
    public void print() {
        System.out.println("Печать документа");
    }

    public void save() {
        System.out.println("Сохранение документа");
    }
}


class Image implements Printable, Exportable {
    public void print() {
        System.out.println("Печать изображения");
    }

    public void export() {
        System.out.println("Экспорт изображения");
    }
}


class Report implements Printable, Savable, Exportable {
    public void print() {
        System.out.println("Печать отчёта");
    }

    public void save() {
        System.out.println("Сохранение отчёта");
    }

    public void export() {
        System.out.println("Экспорт отчёта");
    }
}


public class Main {
    public static void main(String[] args) {

        Document document = new Document();
        Image image = new Image();
        Report report = new Report();

        document.print();
        document.save();

        image.print();
        image.export();

        report.print();
        report.save();
        report.export();
    }
}